# PropBills Netlify Project

## Files
- `index.html` — website checkout
- `netlify/functions/create-payment.js` — secure Square payment backend
- `netlify.toml` — Netlify configuration

## Before deploying
In Netlify, add these environment variables:

- `SQUARE_ACCESS_TOKEN` = your **Production Access Token** from Square
- `SQUARE_LOCATION_ID` = `LAVKZDTN3AQSY`

Do NOT put the access token into `index.html`.

## Square credentials already configured in the browser
- Application ID: `sq0idp-YtzsPCv1sJ8T43s4k7Wz9g`
- Location ID: `LAVKZDTN3AQSY`

## Deploy
1. Download and unzip this project.
2. Go to Netlify.
3. Add a new site/project.
4. Upload or connect the entire project folder.
5. In Site configuration > Environment variables, add the two variables above.
6. Redeploy.
7. Test before taking live payments.

## Important
Cash App Pay and Apple Pay availability depends on your Square account, location, device/browser, domain configuration, and Square approval. Apple Pay also requires HTTPS and domain/merchant configuration.

This project intentionally does not include PayPal or Zelle because those require separate official merchant integrations and credentials.

Before processing live payments, confirm your exact products and business model are permitted by Square and applicable law.
