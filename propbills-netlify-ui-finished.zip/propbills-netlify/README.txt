PROP BILLS NETLIFY PROJECT

FILES
- index.html: website checkout
- netlify/functions/: secure payment functions
- .env.example: names of required environment variables

NETLIFY SETUP
1. Upload this project to Netlify.
2. In Netlify: Site configuration -> Environment variables, add:
   SQUARE_ACCESS_TOKEN
   SQUARE_LOCATION_ID
   PAYPAL_CLIENT_ID
   PAYPAL_CLIENT_SECRET
3. Never put SQUARE_ACCESS_TOKEN or PAYPAL_CLIENT_SECRET into index.html.
4. Replace PAYPAL_CLIENT_ID in index.html with your public PayPal Client ID.
5. Test in the providers' sandbox/test environments before live payments.

IMPORTANT
The site validates package prices and promo codes again on the server before creating Square or PayPal payments.
Cash App Pay and Apple Pay require that the Square account, domain, browser/device, and merchant configuration are eligible and correctly configured.
This starter project does not store orders after payment. Add a database and provider webhooks before production fulfillment.
